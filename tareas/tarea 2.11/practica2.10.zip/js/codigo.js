function tabla() 
{
	var  numero = document.getElementById("numero").value;
	var  parrafo = document.getElementById("vacio");
	if (numero == null || /^\s+$/.test(numero) || isNaN(numero)) 
	{
		alert("Inserta un numero por favor");
		return;
	}
	for (let i = 1; i <= 10; i++) {
		parrafo.innerHTML = parrafo.innerHTML + "<br>" + numero + " x " + i + " = " + numero * i;
		}
}
